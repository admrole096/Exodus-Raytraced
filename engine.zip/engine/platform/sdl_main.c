/* platform/sdl_main.c - composition root + SDL2 platform layer. UNTESTED in the sandbox (no display/SDL).
 * Platform job: window, event pump -> input_t, timing, blit. Everything else is modules.
 * To add a feature: write modules/yourmod.h, #include it, add one game_register() line below.
 * Usage: engine_sdl [model.obj|model.m3d] */
#include <SDL2/SDL.h>
#include "game.h"
#include "controls.h"
#include "world.h"
#include "demo_scene.h"
#include "player.h"
#include "hud.h"

static int map_key(SDL_Keycode k){
  if((k>='a'&&k<='z')||(k>='0'&&k<='9')) return (int)k;
  switch(k){
    case SDLK_SPACE: return K_SPACE;   case SDLK_ESCAPE: return K_ESC;   case SDLK_RETURN: return K_ENTER;
    case SDLK_TAB: return K_TAB;       case SDLK_BACKSPACE: return K_BACKSPACE;
    case SDLK_LCTRL: return K_LCTRL;   case SDLK_RCTRL: return K_RCTRL;
    case SDLK_LSHIFT: return K_LSHIFT; case SDLK_RSHIFT: return K_RSHIFT;
    case SDLK_LALT: return K_LALT;     case SDLK_RALT: return K_RALT;
    case SDLK_UP: return K_UP; case SDLK_DOWN: return K_DOWN; case SDLK_LEFT: return K_LEFT; case SDLK_RIGHT: return K_RIGHT;
    case SDLK_BACKQUOTE: return '`';
  }
  return 0;
}

static game_t G;

int main(int argc,char **argv){
  engine_init();
  game_init(&G);
  if(argc>1) demo_model_path=argv[1];
  /* ORDER MATTERS: controls -> world -> content -> player -> hud */
  game_register(&G,&controls_module);
  game_register(&G,&world_module);
  game_register(&G,&demo_scene_module);
  game_register(&G,&player_module);
  game_register(&G,&hud_module);

  SDL_Init(SDL_INIT_VIDEO);
  SDL_Window *w=SDL_CreateWindow("engine",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,SW*5,SH*5,SDL_WINDOW_RESIZABLE);
  SDL_Renderer *r=SDL_CreateRenderer(w,-1,SDL_RENDERER_PRESENTVSYNC);
  SDL_RenderSetLogicalSize(r,SW,SH);
  SDL_Texture *tx=SDL_CreateTexture(r,SDL_PIXELFORMAT_ARGB8888,SDL_TEXTUREACCESS_STREAMING,SW,SH);
  SDL_SetRelativeMouseMode(SDL_TRUE);

  static uint32_t pix[SW*SH]; uint32_t last=SDL_GetTicks();
  while(G.running){
    input_begin_frame(&G.in);
    SDL_Event e;
    while(SDL_PollEvent(&e)){
      if(e.type==SDL_QUIT) G.running=0;
      else if(e.type==SDL_KEYDOWN||e.type==SDL_KEYUP){ int k=map_key(e.key.keysym.sym); if(k) input_key(&G.in,k,e.type==SDL_KEYDOWN); }
      else if(e.type==SDL_MOUSEMOTION) input_mouse(&G.in,e.motion.xrel,e.motion.yrel);
    }
    uint32_t now=SDL_GetTicks(), raw=now-last; last=now;
    game_frame(&G,raw);
    blit_rgb(pix);
    SDL_UpdateTexture(tx,0,pix,SW*4); SDL_RenderClear(r); SDL_RenderCopy(r,tx,0,0); SDL_RenderPresent(r);
  }
  game_shutdown(&G);
  SDL_Quit(); return 0;
}
