/* objconv in.obj out.m3d [scale] [hue]      -> binary mesh
 * objconv in.obj out.h   [scale] [hue] --c  -> C arrays (no loader needed at runtime) */
#include "obj.h"
int main(int argc,char **argv){
  if(argc<3){ fprintf(stderr,"usage: objconv in.obj out [scale] [hue] [--c]\n"); return 1; }
  double sc=argc>3?atof(argv[3]):1.0; int hue=argc>4?atoi(argv[4])&15:1;
  int asc=argc>5&&!strcmp(argv[5],"--c");
  mesh_t m; int r=obj_load(argv[1],sc,(uint8_t)hue,&m);
  if(r){ fprintf(stderr,"load failed (%d): %s\n",r,r==-2?"more than 256 vertices - decimate first":r==-3?"no geometry":"cannot open"); return 1; }
  if(asc){ FILE *o=fopen(argv[2],"w"); if(!o) return 1; mesh_emit_c(&m,"mesh",o); fclose(o); }
  else if(mesh_save(&m,argv[2])) return 1;
  printf("%d verts, %d tris\n",m.nv,m.nt); mesh_free(&m); return 0;
}
