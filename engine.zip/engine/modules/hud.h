/* modules/hud.h - FPS counter (top centre). Command: showfps [0|1]. Uses the unclamped frame time. */
#ifndef HUD_H
#define HUD_H
#include <stdio.h>
#include "game.h"
#include "text.h"

typedef struct { uint32_t acc,frames; int fps,show; } hud_state_t;
static hud_state_t HUD;

static int cmd_showfps(game_t *g,int argc,char **argv,char *out,int outn){
  (void)g; if(argc==2) HUD.show=atoi(argv[1])!=0;
  OUT("showfps %d",HUD.show); return 0;
}
static void hud_init(game_t *g){
  memset(&HUD,0,sizeof HUD); HUD.show=1; game_service_set(g,"hud",&HUD);
  game_cmd_register(g,"showfps",cmd_showfps,"showfps [0|1]");
}
static void hud_update(game_t *g){
  HUD.acc+=g->raw_dt_ms; HUD.frames++;
  if(HUD.acc>=500){ HUD.fps=(int)(HUD.frames*1000/HUD.acc); HUD.acc=0; HUD.frames=0; }
}
static void hud_draw(game_t *g){
  (void)g; if(!HUD.show) return;
  char b[24]; snprintf(b,sizeof b,"FPS %d",HUD.fps);
  draw_text_f(&FONT35,(SW-text_width(&FONT35,b))/2,2,b,11*16+0,12*16+9);
}
static const module_t hud_module={GAME_API_VERSION,"hud",hud_init,hud_update,0,hud_draw,0};
#endif
