/* modules/demo_scene.h - example content module: ground slab, a cube, optional model from a file.
 * Shows how content is "just another module" that feeds the world service. Register AFTER world. */
#ifndef DEMO_SCENE_H
#define DEMO_SCENE_H
#include <string.h>
#include "game.h"
#include "shapes.h"
#include "obj.h"
#include "world.h"

static const char *demo_model_path=0;     /* set by the platform before registering */

static void demo_init(game_t *g){
  world_t *w=game_service(g,"world"); if(!w) return;
  v3 v[8]; tri_t t[12];
  box_mesh(0,FXF(-1.5),0,FXF(30),FXF(0.5),FXF(30),4,v,t); world_add_mesh(w,v,8,t,12);   /* ground, top y=-1 */
  box_mesh(0,0,FXF(4),FXF(1),FXF(1),FXF(1),1,v,t);        world_add_mesh(w,v,8,t,12);   /* cube */
  if(demo_model_path){
    mesh_t m; size_t n=strlen(demo_model_path);
    int rc=(n>4&&!strcmp(demo_model_path+n-4,".m3d"))?mesh_load(&m,demo_model_path):obj_load(demo_model_path,1.0,5,&m);
    if(rc==0){ mesh_translate(&m,4,-1,6); world_add_mesh(w,m.v,m.nv,m.t,m.nt); mesh_free(&m); }
    else fprintf(stderr,"demo_scene: could not load %s (rc=%d)\n",demo_model_path,rc);
  }
}
static const module_t demo_scene_module={GAME_API_VERSION,"demo_scene",demo_init,0,0,0,0};
#endif
