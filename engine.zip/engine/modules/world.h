/* modules/world.h - owns the STATIC world: source triangles, the BSP built from them, and the ground provider
 * physics uses. Other modules add geometry at runtime with world_add_mesh(); the BSP is rebuilt between frames
 * (update hook) when dirty. Service: "world" -> world_t*. */
#ifndef WORLD_H
#define WORLD_H
#include "game.h"
#include "bsp.h"
#include "physics.h"

typedef struct { tri_list tl; bsp_t bsp; int built,dirty; } world_t;
static world_t WORLD;

static void world_add_mesh(world_t *w,const v3 *v,int nv,const tri_t *t,int nt){
  tl_add_mesh(&w->tl,v,nv,t,nt); w->dirty=1;
}
static void world_rebuild(world_t *w){
  if(w->built) bsp_free(&w->bsp);
  bsp_build(&w->tl,&w->bsp); w->built=1; w->dirty=0;
}
/* floor_fn over the world's source triangles (ctx = world_t*) */
static int world_floor(void *ctx,fx px,fx pz,fx ymax,fx *out){
  world_t *w=ctx; int found=0; fx best=0;
  for(int i=0;i<w->tl.n;i++){
    const wtri_t *T=&w->tl.t[i]; fx y;
    if(tri_floor_test(T->v[0],T->v[1],T->v[2],px,pz,ymax,&y) && (!found||y>best)){ best=y; found=1; }
  }
  *out=best; return found;
}

static void world_init(game_t *g){ memset(&WORLD,0,sizeof WORLD); game_service_set(g,"world",&WORLD); }
static void world_update(game_t *g){ (void)g; if(WORLD.dirty) world_rebuild(&WORLD); }
static void world_draw(game_t *g){ if(WORLD.built) bsp_render(&WORLD.bsp,&g->cam,g->fog_start,g->fog_end); }
static void world_shutdown(game_t *g){ (void)g; if(WORLD.built) bsp_free(&WORLD.bsp); free(WORLD.tl.t); memset(&WORLD,0,sizeof WORLD); }
static const module_t world_module={GAME_API_VERSION,"world",world_init,world_update,world_draw,0,world_shutdown};
#endif
