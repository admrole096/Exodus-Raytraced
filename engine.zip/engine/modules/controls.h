/* modules/controls.h - key bindings + mouse look. Turns raw input into ACTIONS (g->act_down/act_pressed)
 * and view angles (g->yaw_i/pitch_i). Rebindable at runtime: controls_bind(), or the `bind` command.
 * Register BEFORE modules that read actions. */
#ifndef CONTROLS_H
#define CONTROLS_H
#include "game.h"

typedef struct { uint8_t key,act; } binding_t;
typedef struct { binding_t b[64]; int n; int sens; } controls_state_t;   /* sens: turn units per mouse count */
static controls_state_t CTL;

static int controls_bind(int key,int act){
  if(key<=0||key>255||act<0||act>=MAX_ACTIONS) return -1;
  for(int i=0;i<CTL.n;i++) if(CTL.b[i].key==key&&CTL.b[i].act==act) return 0;
  if(CTL.n>=64) return -1;
  CTL.b[CTL.n].key=(uint8_t)key; CTL.b[CTL.n++].act=(uint8_t)act; return 0;
}
static void controls_unbind_key(int key){
  int j=0; for(int i=0;i<CTL.n;i++) if(CTL.b[i].key!=key) CTL.b[j++]=CTL.b[i];
  CTL.n=j;
}

static int cmd_bind(game_t *g,int argc,char **argv,char *out,int outn){
  if(argc!=3){ OUT("usage: bind <key> <action>"); return -1; }
  int k=key_from_name(argv[1]), a=game_action_id(g,argv[2],0);
  if(!k){ OUT("unknown key: %s",argv[1]); return -1; }
  if(a<0){ OUT("unknown action: %s",argv[2]); return -1; }
  if(controls_bind(k,a)){ OUT("bind failed"); return -1; }
  OUT("bound %s -> %s",argv[1],argv[2]); return 0;
}
static int cmd_unbind(game_t *g,int argc,char **argv,char *out,int outn){
  (void)g; int k=argc==2?key_from_name(argv[1]):0;
  if(!k){ OUT("usage: unbind <key>"); return -1; }
  controls_unbind_key(k); OUT("unbound %s",argv[1]); return 0;
}
static int cmd_sens(game_t *g,int argc,char **argv,char *out,int outn){
  (void)g; if(argc==2) CTL.sens=atoi(argv[1]);
  OUT("sens %d",CTL.sens); return 0;
}

static void controls_init(game_t *g){
  memset(&CTL,0,sizeof CTL); CTL.sens=20;
  controls_bind('w',ACT_FORWARD); controls_bind('s',ACT_BACK);
  controls_bind('a',ACT_LEFT);    controls_bind('d',ACT_RIGHT);
  controls_bind(K_SPACE,ACT_JUMP);
  controls_bind(K_LCTRL,ACT_DOWN); controls_bind(K_RCTRL,ACT_DOWN);
  controls_bind('p',ACT_TOGGLE_PHYSICS); controls_bind(K_ESC,ACT_QUIT);
  game_service_set(g,"controls",&CTL);
  game_cmd_register(g,"bind",cmd_bind,"bind <key> <action>");
  game_cmd_register(g,"unbind",cmd_unbind,"unbind <key>");
  game_cmd_register(g,"sens",cmd_sens,"sens <n> : mouse sensitivity");
}
static void controls_update(game_t *g){
  memset(g->act_down,0,sizeof g->act_down); memset(g->act_pressed,0,sizeof g->act_pressed);
  for(int i=0;i<CTL.n;i++){
    if(g->in.down[CTL.b[i].key])    g->act_down[CTL.b[i].act]=1;
    if(g->in.pressed[CTL.b[i].key]) g->act_pressed[CTL.b[i].act]=1;
  }
  g->yaw_i=(g->yaw_i+g->in.mouse_dx*CTL.sens)&0xFFFF;
  g->pitch_i-=g->in.mouse_dy*CTL.sens;
  int lim=DEG(85); if(g->pitch_i>lim) g->pitch_i=lim; if(g->pitch_i<-lim) g->pitch_i=-lim;
  if(g->act_pressed[ACT_QUIT]) g->running=0;
}
static const module_t controls_module={GAME_API_VERSION,"controls",controls_init,controls_update,0,0,0};
#endif
