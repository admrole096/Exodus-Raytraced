/* modules/player.h - the player body. Reads ACTIONS, runs core/physics.h, publishes the camera (g->cam).
 * Service: "player" -> player_state_t* (other modules can read/modify params and add floor sources).
 * Register AFTER controls and world. Commands: physics, gravity, tp. */
#ifndef PLAYER_H
#define PLAYER_H
#include "game.h"
#include "physics.h"
#include "world.h"

#define MAX_FLOOR_SOURCES 8
typedef struct {
  player_t pl; phys_params_t pp; int physics_on;
  floor_source src[MAX_FLOOR_SOURCES]; int nsrc;
} player_state_t;
static player_state_t PLAYER;

static int player_add_floor_source(player_state_t *p,floor_fn fn,void *ctx){
  if(p->nsrc>=MAX_FLOOR_SOURCES) return -1;
  p->src[p->nsrc].fn=fn; p->src[p->nsrc++].ctx=ctx; return 0;
}

static int cmd_physics(game_t *g,int argc,char **argv,char *out,int outn){
  (void)g;
  if(argc==2) PLAYER.physics_on=!strcmp(argv[1],"on");
  if(argc==2&&PLAYER.physics_on) PLAYER.pl.vy=0;
  OUT("physics %s",PLAYER.physics_on?"on":"off"); return 0;
}
static int cmd_gravity(game_t *g,int argc,char **argv,char *out,int outn){
  (void)g; if(argc==2) PLAYER.pp.gravity=FXF(atof(argv[1]));
  OUT("gravity %.2f",PLAYER.pp.gravity/65536.0); return 0;
}
static int cmd_tp(game_t *g,int argc,char **argv,char *out,int outn){
  (void)g;
  if(argc!=4){ OUT("usage: tp <x> <y> <z>"); return -1; }
  PLAYER.pl.pos=(v3){FXF(atof(argv[1])),FXF(atof(argv[2])),FXF(atof(argv[3]))};
  PLAYER.pl.vx=PLAYER.pl.vy=PLAYER.pl.vz=0; PLAYER.pl.ground=0;
  OUT("teleported"); return 0;
}

static void player_init(game_t *g){
  memset(&PLAYER,0,sizeof PLAYER);
  PLAYER.pp=phys_defaults(); PLAYER.physics_on=1; PLAYER.pl.pos=(v3){0,FXF(2),FXF(-5)};
  world_t *w=game_service(g,"world");
  if(w) player_add_floor_source(&PLAYER,world_floor,w);
  game_service_set(g,"player",&PLAYER);
  game_cmd_register(g,"physics",cmd_physics,"physics [on|off]");
  game_cmd_register(g,"gravity",cmd_gravity,"gravity <units/s^2>");
  game_cmd_register(g,"tp",cmd_tp,"tp <x> <y> <z>");
}
static void player_update(game_t *g){
  int f=g->act_down[ACT_FORWARD]-g->act_down[ACT_BACK], sd=g->act_down[ACT_RIGHT]-g->act_down[ACT_LEFT];
  uint16_t yaw=(uint16_t)g->yaw_i;
  if(g->act_pressed[ACT_TOGGLE_PHYSICS]){ PLAYER.physics_on=!PLAYER.physics_on; PLAYER.pl.vy=0; }
  if(PLAYER.physics_on) player_step(&PLAYER.pl,&PLAYER.pp,PLAYER.src,PLAYER.nsrc,f,sd,g->act_down[ACT_JUMP],yaw,g->dt);
  else player_fly(&PLAYER.pl,&PLAYER.pp,f,sd,g->act_down[ACT_JUMP]-g->act_down[ACT_DOWN],yaw,g->dt);
  g->cam.pos=(v3){PLAYER.pl.pos.x,PLAYER.pl.pos.y+PLAYER.pp.eye_h,PLAYER.pl.pos.z};
  g->cam.yaw=yaw; g->cam.pitch=(uint16_t)g->pitch_i;
}
static const module_t player_module={GAME_API_VERSION,"player",player_init,player_update,0,0,0};
#endif
