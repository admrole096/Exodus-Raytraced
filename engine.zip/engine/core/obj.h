/* core/obj.h - FROZEN (see docs/ARCHITECTURE.md). */
/* obj.h - OBJ -> engine mesh converter library + tiny binary format (.m3d).
 * Offline/spawn-time only (uses stdio, malloc, strtod); the render path stays integer.
 * Conventions: OBJ is right-handed/CCW; engine is z-forward, so z is negated and the
 * winding is kept. Triangles use uint8 indices => max 256 verts per mesh (low poly on purpose).
 * Lighting is BAKED: each triangle gets a shade 0..7 from its normal vs a fixed light. */
#ifndef OBJ_H
#define OBJ_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "engine.h"

typedef struct { v3 *v; int nv; tri_t *t; int nt; } mesh_t;
static void mesh_free(mesh_t *m){ free(m->v); free(m->t); m->v=0; m->t=0; m->nv=m->nt=0; }

static uint8_t bake_bright(v3 a,v3 b,v3 c){
  double ax=(c.x-a.x)/65536.0, ay=(c.y-a.y)/65536.0, az=(c.z-a.z)/65536.0;
  double bx=(b.x-a.x)/65536.0, by=(b.y-a.y)/65536.0, bz=(b.z-a.z)/65536.0;
  double nx=ay*bz-az*by, ny=az*bx-ax*bz, nz=ax*by-ay*bx;      /* (c-a)x(b-a) = outward */
  double nl=sqrt(nx*nx+ny*ny+nz*nz); if(nl<1e-9) return 7;
  double lx=0.40,ly=0.80,lz=-0.45, ll=sqrt(lx*lx+ly*ly+lz*lz);
  double d=(nx*lx+ny*ly+nz*lz)/(nl*ll); if(d<0) d=0;
  int b7=(int)((1.0-d)*7.0); return (uint8_t)(b7>7?7:b7);
}

/* returns 0 ok, -1 io, -2 too many verts, -3 no geometry */
static int obj_load(const char *path,double scale,uint8_t hue,mesh_t *m){
  FILE *f=fopen(path,"r"); if(!f) return -1;
  int vcap=64,tcap=64,nv=0,nt=0; v3 *v=malloc(vcap*sizeof *v); tri_t *t=malloc(tcap*sizeof *t);
  char line[512]; int err=0;
  while(fgets(line,sizeof line,f)){
    if(line[0]=='v'&&line[1]==' '){
      double x,y,z; if(sscanf(line+2,"%lf %lf %lf",&x,&y,&z)!=3) continue;
      if(nv>=256){ err=-2; break; }
      if(nv==vcap){ vcap*=2; v=realloc(v,vcap*sizeof *v); }
      v[nv].x=(fx)floor(x*scale*65536.0+0.5); v[nv].y=(fx)floor(y*scale*65536.0+0.5);
      v[nv].z=(fx)floor(-z*scale*65536.0+0.5);                 /* z flip */
      nv++;
    } else if(line[0]=='f'&&line[1]==' '){
      int idx[32],n=0; char *p=line+2;
      while(*p && n<32){
        while(*p==' '||*p=='\t') p++;
        if(*p=='\n'||*p=='\r'||!*p) break;
        long i=strtol(p,&p,10);
        while(*p && *p!=' ' && *p!='\t' && *p!='\n' && *p!='\r') p++;   /* skip /vt/vn */
        idx[n++]=(int)(i<0? nv+i : i-1);
      }
      for(int k=1;k+1<n;k++){                                   /* fan triangulate */
        int a=idx[0],b=idx[k],c=idx[k+1];
        if(a<0||b<0||c<0||a>=nv||b>=nv||c>=nv) continue;
        if(nt==tcap){ tcap*=2; t=realloc(t,tcap*sizeof *t); }
        t[nt++]=(tri_t){(uint8_t)a,(uint8_t)b,(uint8_t)c,hue,bake_bright(v[a],v[b],v[c])};
      }
    }
  }
  fclose(f);
  if(!err && (nv==0||nt==0)) err=-3;
  if(err){ free(v); free(t); return err; }
  m->v=v; m->nv=nv; m->t=t; m->nt=nt; return 0;
}

static void mesh_translate(mesh_t *m,double dx,double dy,double dz){
  for(int i=0;i<m->nv;i++){
    m->v[i].x+=(fx)floor(dx*65536.0+0.5); m->v[i].y+=(fx)floor(dy*65536.0+0.5);
    m->v[i].z+=(fx)floor(dz*65536.0+0.5);
  }
}

/* .m3d: "M3D1", u16 nv, u16 nt, nv*(i32 x,y,z), nt*(u8 a,b,c,hue,bright). Little-endian host. */
static int mesh_save(const mesh_t *m,const char *path){
  FILE *f=fopen(path,"wb"); if(!f) return -1;
  uint16_t nv=(uint16_t)m->nv, nt=(uint16_t)m->nt;
  fwrite("M3D1",1,4,f); fwrite(&nv,2,1,f); fwrite(&nt,2,1,f);
  fwrite(m->v,sizeof(v3),nv,f); fwrite(m->t,sizeof(tri_t),nt,f);
  fclose(f); return 0;
}
static int mesh_load(mesh_t *m,const char *path){
  FILE *f=fopen(path,"rb"); if(!f) return -1;
  char mg[4]; uint16_t nv,nt;
  if(fread(mg,1,4,f)!=4||memcmp(mg,"M3D1",4)||fread(&nv,2,1,f)!=1||fread(&nt,2,1,f)!=1||nv>256){ fclose(f); return -2; }
  m->v=malloc(nv*sizeof(v3)); m->t=malloc(nt*sizeof(tri_t)); m->nv=nv; m->nt=nt;
  if(fread(m->v,sizeof(v3),nv,f)!=nv||fread(m->t,sizeof(tri_t),nt,f)!=nt){ fclose(f); mesh_free(m); return -2; }
  fclose(f); return 0;
}
static void mesh_emit_c(const mesh_t *m,const char *name,FILE *o){
  fprintf(o,"static const v3 %s_v[%d]={\n",name,m->nv);
  for(int i=0;i<m->nv;i++) fprintf(o,"{%d,%d,%d},",m->v[i].x,m->v[i].y,m->v[i].z);
  fprintf(o,"\n};\nstatic const tri_t %s_t[%d]={\n",name,m->nt);
  for(int i=0;i<m->nt;i++) fprintf(o,"{%u,%u,%u,%u,%u},",m->t[i].a,m->t[i].b,m->t[i].c,m->t[i].hue,m->t[i].bright);
  fprintf(o,"\n};\n");
}
#endif
