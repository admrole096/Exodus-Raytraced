/* core/bsp.h - FROZEN (see docs/ARCHITECTURE.md). */
/* bsp.h - static-world BSP: build (spawn-time) + back-to-front painter traversal (runtime).
 * Triangle soup in, split triangles + node array out. Runtime is integer-only.
 * World triangles carry their own 3 vertices (wtri_t) because splitting creates new verts,
 * which would not fit the 8-bit vertex indices of tri_t. */
#ifndef BSP_H
#define BSP_H
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "engine.h"

typedef struct { v3 v[3]; uint8_t hue,bright; } wtri_t;
typedef struct { fx nx,ny,nz,d; int front,back,first,count; } bsp_node;   /* plane: n.p = d */
typedef struct { bsp_node *n; int nn,ncap; wtri_t *t; int nt,tcap; int root,splits; } bsp_t;
typedef struct { wtri_t *t; int n,cap; } tri_list;

static void tl_push(tri_list *L,wtri_t T){
  if(L->n==L->cap){ L->cap=L->cap?L->cap*2:64; L->t=realloc(L->t,L->cap*sizeof *L->t); }
  L->t[L->n++]=T;
}
static void tl_add_mesh(tri_list *L,const v3 *v,int nv,const tri_t *t,int nt){
  (void)nv;
  for(int i=0;i<nt;i++) tl_push(L,(wtri_t){{v[t[i].a],v[t[i].b],v[t[i].c]},t[i].hue,t[i].bright});
}

typedef struct { double nx,ny,nz,d; int ok; } plane_t;
#define BSP_EPS 0.004
static inline double fd(fx v){ return v/65536.0; }

static plane_t plane_of(const wtri_t *T){
  double ax=fd(T->v[0].x),ay=fd(T->v[0].y),az=fd(T->v[0].z);
  double ux=fd(T->v[2].x)-ax,uy=fd(T->v[2].y)-ay,uz=fd(T->v[2].z)-az;   /* c-a */
  double vx=fd(T->v[1].x)-ax,vy=fd(T->v[1].y)-ay,vz=fd(T->v[1].z)-az;   /* b-a */
  plane_t P; double nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;      /* (c-a)x(b-a) = outward */
  double l=sqrt(nx*nx+ny*ny+nz*nz);
  P.ok=l>1e-6; if(!P.ok){ P.nx=P.ny=P.nz=P.d=0; return P; }
  P.nx=nx/l; P.ny=ny/l; P.nz=nz/l; P.d=P.nx*ax+P.ny*ay+P.nz*az; return P;
}
static inline double pdist(const plane_t *P,v3 p){ return P->nx*fd(p.x)+P->ny*fd(p.y)+P->nz*fd(p.z)-P->d; }

/* 1 front, -1 back, 0 coplanar, 2 straddles */
static int classify(const plane_t *P,const wtri_t *T){
  int f=0,b=0;
  for(int i=0;i<3;i++){ double d=pdist(P,T->v[i]); if(d>BSP_EPS) f=1; else if(d<-BSP_EPS) b=1; }
  return f&&b ? 2 : f ? 1 : b ? -1 : 0;
}

static void emit_poly(const v3 *pv,int n,const wtri_t *src,wtri_t *out,int *cnt){
  for(int k=1;k+1<n;k++){
    wtri_t T={{pv[0],pv[k],pv[k+1]},src->hue,src->bright};
    if(plane_of(&T).ok) out[(*cnt)++]=T;                 /* drop zero-area slivers */
  }
}
static void split_tri(const plane_t *P,const wtri_t *T,wtri_t *fr,int *nf,wtri_t *bk,int *nb){
  double d[3]; int s[3]; v3 fp[5],bp[5]; int nfp=0,nbp=0;
  for(int i=0;i<3;i++){ d[i]=pdist(P,T->v[i]); s[i]=d[i]>BSP_EPS?1:d[i]<-BSP_EPS?-1:0; }
  for(int i=0;i<3;i++){
    int j=(i+1)%3; v3 vi=T->v[i], vj=T->v[j];
    if(s[i]>=0) fp[nfp++]=vi;
    if(s[i]<=0) bp[nbp++]=vi;
    if(s[i]*s[j]<0){
      double t=d[i]/(d[i]-d[j]); v3 m;
      m.x=(fx)floor(vi.x+(double)(vj.x-vi.x)*t+0.5);
      m.y=(fx)floor(vi.y+(double)(vj.y-vi.y)*t+0.5);
      m.z=(fx)floor(vi.z+(double)(vj.z-vi.z)*t+0.5);
      fp[nfp++]=m; bp[nbp++]=m;
    }
  }
  if(nfp>=3) emit_poly(fp,nfp,T,fr,nf);
  if(nbp>=3) emit_poly(bp,nbp,T,bk,nb);
}

/* try ~16 candidate planes; prefer few splits, then balance */
static int pick_splitter(const wtri_t *L,int n){
  int step=n>16?n/16:1, best=0; double bs=1e30;
  for(int s=0;s<n;s+=step){
    plane_t P=plane_of(&L[s]); int f=0,b=0,sp=0;
    for(int i=0;i<n;i++){ int c=classify(&P,&L[i]); if(c==1) f++; else if(c==-1) b++; else if(c==2) sp++; }
    double sc=sp*8.0+fabs((double)(f-b));
    if(sc<bs){ bs=sc; best=s; }
  }
  return best;
}

static int bsp_rec(bsp_t *B,const wtri_t *L,int n){
  if(n==0) return -1;
  plane_t P=plane_of(&L[pick_splitter(L,n)]);
  wtri_t *F=malloc(2*n*sizeof *F), *K=malloc(2*n*sizeof *K), *C=malloc(n*sizeof *C);
  int nf=0,nk=0,nc=0;
  for(int i=0;i<n;i++){
    int c=classify(&P,&L[i]);
    if(c==0) C[nc++]=L[i]; else if(c==1) F[nf++]=L[i]; else if(c==-1) K[nk++]=L[i];
    else { split_tri(&P,&L[i],F,&nf,K,&nk); B->splits++; }
  }
  if(B->nn==B->ncap){ B->ncap=B->ncap?B->ncap*2:32; B->n=realloc(B->n,B->ncap*sizeof *B->n); }
  int idx=B->nn++;
  B->n[idx]=(bsp_node){(fx)floor(P.nx*65536+0.5),(fx)floor(P.ny*65536+0.5),(fx)floor(P.nz*65536+0.5),
                       (fx)floor(P.d*65536+0.5),-1,-1,B->nt,nc};
  if(B->nt+nc>B->tcap){ B->tcap=(B->nt+nc)*2; B->t=realloc(B->t,B->tcap*sizeof *B->t); }
  memcpy(B->t+B->nt,C,nc*sizeof *C); B->nt+=nc;
  free(C);
  int fch=bsp_rec(B,F,nf); B->n[idx].front=fch;
  int bch=bsp_rec(B,K,nk); B->n[idx].back=bch;
  free(F); free(K);
  return idx;
}

static void bsp_build(const tri_list *in,bsp_t *B){
  memset(B,0,sizeof *B);
  wtri_t *tmp=malloc((in->n?in->n:1)*sizeof *tmp); int n=0;
  for(int i=0;i<in->n;i++) if(plane_of(&in->t[i]).ok) tmp[n++]=in->t[i];
  B->root=bsp_rec(B,tmp,n); free(tmp);
}
static void bsp_free(bsp_t *B){ free(B->n); free(B->t); memset(B,0,sizeof *B); }

/* painter: far side, then this node's polygons, then near side. Backface culling hides the rest. */
static void bsp_draw(const bsp_t *B,int ni,const camxf *x,fx fs,fx fe){
  if(ni<0) return;
  const bsp_node *nd=&B->n[ni];
  int64_t side=(((int64_t)nd->nx*x->pos.x+(int64_t)nd->ny*x->pos.y+(int64_t)nd->nz*x->pos.z)>>16)-nd->d;
  int nr=side>0?nd->front:nd->back, fr=side>0?nd->back:nd->front;
  bsp_draw(B,fr,x,fs,fe);
  for(int i=0;i<nd->count;i++){
    const wtri_t *T=&B->t[nd->first+i];
    draw_tri_view(to_view(x,T->v[0]),to_view(x,T->v[1]),to_view(x,T->v[2]),T->hue,T->bright,fs,fe);
  }
  bsp_draw(B,nr,x,fs,fe);
}
static void bsp_render(const bsp_t *B,const cam_t *cam,fx fs,fx fe){
  camxf x; camxf_init(&x,cam); bsp_draw(B,B->root,&x,fs,fe);
}
#endif
