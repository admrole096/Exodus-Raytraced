/* core/shapes.h - FROZEN. Primitive mesh generators. Add new shapes in your own module header. */
#ifndef SHAPES_H
#define SHAPES_H
#include "engine.h"

/* axis-aligned box: 8 verts, 12 tris, faces get different baked shades */
static void box_mesh(fx cx,fx cy,fx cz,fx hx,fx hy,fx hz,uint8_t hue,v3 *v,tri_t *t){
  for(int i=0;i<8;i++){
    v[i].x=cx+((i&1)?hx:-hx); v[i].y=cy+((i&2)?hy:-hy); v[i].z=cz+((i&4)?hz:-hz);
  }
  static const uint8_t f[6][4]={{0,1,3,2},{5,4,6,7},{1,5,7,3},{4,0,2,6},{2,3,7,6},{1,0,4,5}};
  static const uint8_t br[6]={2,5,3,4,0,6};
  for(int i=0;i<6;i++){
    t[i*2  ]=(tri_t){f[i][0],f[i][1],f[i][2],hue,br[i]};
    t[i*2+1]=(tri_t){f[i][0],f[i][2],f[i][3],hue,br[i]};
  }
}
#endif
