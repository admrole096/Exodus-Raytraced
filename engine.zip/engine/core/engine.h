/* core/engine.h - FROZEN. Math, palette, framebuffer, rasterizer, camera transform.
 * Do not edit to add features: write a module (see docs/ARCHITECTURE.md). `make verify` enforces this. */
/* Original note: software 3D core.
 * C99, integer-only hot path (16.16 fixed point), no SIMD, no floats at runtime
 * (libm only used once at init to build the sine table). */
#ifndef ENGINE_H
#define ENGINE_H
#include <stdint.h>
#include <string.h>
#include <math.h>

#define SW 160
#define SH 100
#define BG_INDEX 15         /* framebuffer clear colour = fog colour */
#define FOCAL 80            /* px; 90 deg hfov at 160 wide */
#define MAXV 512            /* max verts per mesh draw call */

typedef int32_t fx;         /* 16.16 */
#define FX_ONE 65536
#define FXF(x) ((fx)((x)*65536.0))
#define NEAR_Z (FX_ONE/4)
#define SCR_LIM 30000       /* screen coord clamp (px); no guard-band clip yet */
#define DEG(d) ((uint16_t)(int)((d)*65536.0/360.0))   /* 65536 = full turn */

static inline fx fxmul(fx a, fx b){ return (fx)(((int64_t)a*b)>>16); }

static fx sintab[1024];
static inline fx fsin(uint16_t a){ return sintab[a>>6]; }
static inline fx fcos(uint16_t a){ return sintab[((a>>6)+256)&1023]; }

typedef struct { fx x,y,z; } v3;
typedef struct { uint8_t a,b,c,hue,bright; } tri_t;   /* bright = baked shade 0..15 */
typedef struct { v3 pos; uint16_t yaw,pitch; } cam_t;

static uint8_t  fb[SW*SH];  /* 8-bit palettized: index = hue*16 + shade */
static uint32_t pal[256];   /* 0xAARRGGBB */

static const uint8_t hue_rgb[16][3] = {
 {200,200,200},{210, 60, 60},{230,130, 40},{230,210, 60},
 { 70,190, 70},{ 50,170,140},{ 70,200,220},{ 70,100,220},
 {140, 80,210},{210, 80,190},{140, 95, 60},{250,250,250},
 {100,100,100},{ 40,110, 50},{ 60, 60,120},{120,150, 90}};
static const uint8_t fog_rgb[3] = {28,32,48};

static void engine_init(void){
  for(int i=0;i<1024;i++) sintab[i]=(fx)floor(sin(i*6.283185307179586/1024.0)*65536.0+0.5);
  for(int h=0;h<16;h++) for(int s=0;s<16;s++){
    uint32_t c=0xFF000000u;
    for(int k=0;k<3;k++){
      int v=hue_rgb[h][k]*(15-s)/15 + fog_rgb[k]*s/15;
      c |= (uint32_t)v << (16-8*k);
    }
    pal[h*16+s]=c;
  }
}

static inline void clear_fb(uint8_t col){ memset(fb,col,sizeof fb); }
static inline void blit_rgb(uint32_t *dst){ for(int i=0;i<SW*SH;i++) dst[i]=pal[fb[i]]; }

/* flat scanline triangle fill; coords 16.16 screen px */
static void fill_tri(int32_t x0,int32_t y0,int32_t x1,int32_t y1,int32_t x2,int32_t y2,uint8_t col){
  int32_t t;
  if(y0>y1){t=x0;x0=x1;x1=t;t=y0;y0=y1;y1=t;}
  if(y1>y2){t=x1;x1=x2;x2=t;t=y1;y1=y2;y2=t;}
  if(y0>y1){t=x0;x0=x1;x1=t;t=y0;y0=y1;y1=t;}
  int ys=(y0+0xFFFF)>>16; if(ys<0) ys=0;
  int ye=(y2+0xFFFF)>>16; if(ye>SH) ye=SH;
  for(int y=ys;y<ye;y++){
    int64_t fy=(int64_t)y<<16;
    int32_t xa=x0+(int32_t)(((int64_t)(x2-x0)*(fy-y0))/(y2-y0));
    int32_t xb;
    if(fy<y1) xb=x0+(int32_t)(((int64_t)(x1-x0)*(fy-y0))/(y1-y0));
    else      xb=x1+(int32_t)(((int64_t)(x2-x1)*(fy-y1))/(y2-y1));
    if(xa>xb){t=xa;xa=xb;xb=t;}
    int xs=(xa+0xFFFF)>>16; if(xs<0) xs=0;
    int xe=(xb+0xFFFF)>>16; if(xe>SW) xe=SW;
    if(xe>xs) memset(fb+y*SW+xs,col,xe-xs);
  }
}

static int clip_near(const v3 *in,int n,v3 *out){
  int m=0;
  for(int i=0;i<n;i++){
    v3 a=in[i], b=in[(i+1)%n];
    int ai=a.z>=NEAR_Z, bi=b.z>=NEAR_Z;
    if(ai) out[m++]=a;
    if(ai!=bi){
      /* always interpolate from the inside vertex so shared edges clip identically (no cracks) */
      v3 in_=ai?a:b, out_=ai?b:a;
      int64_t t=((int64_t)(NEAR_Z-in_.z)<<16)/(out_.z-in_.z);
      v3 c; c.z=NEAR_Z;
      c.x=in_.x+(fx)(((int64_t)(out_.x-in_.x)*t)>>16);
      c.y=in_.y+(fx)(((int64_t)(out_.y-in_.y)*t)>>16);
      out[m++]=c;
    }
  }
  return m;
}

static inline void project(v3 v,int32_t *sx,int32_t *sy){
  int64_t px=(((int64_t)v.x*FOCAL)<<16)/v.z + ((int64_t)(SW/2)<<16);
  int64_t py=((int64_t)(SH/2)<<16) - (((int64_t)v.y*FOCAL)<<16)/v.z;
  int64_t lim=(int64_t)SCR_LIM<<16;
  if(px>lim) px=lim;
  if(px<-lim) px=-lim;
  if(py>lim) py=lim;
  if(py<-lim) py=-lim;
  *sx=(int32_t)px; *sy=(int32_t)py;
}

typedef struct { fx sy,cy,sp,cp; v3 pos; } camxf;      /* per-frame camera transform */
static inline void camxf_init(camxf *x,const cam_t *c){
  x->sy=fsin(c->yaw); x->cy=fcos(c->yaw); x->sp=fsin(c->pitch); x->cp=fcos(c->pitch); x->pos=c->pos;
}
static inline v3 to_view(const camxf *x,v3 p){
  fx dx=p.x-x->pos.x, dy=p.y-x->pos.y, dz=p.z-x->pos.z;
  fx x1=fxmul(dx,x->cy)-fxmul(dz,x->sy), z1=fxmul(dx,x->sy)+fxmul(dz,x->cy);
  v3 r; r.x=x1; r.y=fxmul(dy,x->cp)-fxmul(z1,x->sp); r.z=fxmul(dy,x->sp)+fxmul(z1,x->cp);
  return r;
}
static inline uint8_t tri_color(fx z0,fx z1,fx z2,uint8_t hue,uint8_t bright,fx fs,fx fe){
  fx zavg=(z0+z1+z2)/3; if(zavg<NEAR_Z) zavg=NEAR_Z;
  int fog = zavg<=fs ? 0 : zavg>=fe ? 15 : (int)(((int64_t)(zavg-fs)*15)/(fe-fs));
  int sh=bright+fog; if(sh>15) sh=15;
  return (uint8_t)(hue*16+sh);
}

/* Draw one triangle given in VIEW space. Shared by render_mesh and the BSP renderer. */
static void draw_tri_view(v3 a,v3 b,v3 c,uint8_t hue,uint8_t bright,fx fog_start,fx fog_end){
  v3 p[3]={a,b,c};
  fx zmax=p[0].z>p[1].z?p[0].z:p[1].z; if(p[2].z>zmax) zmax=p[2].z;
  fx zmin=p[0].z<p[1].z?p[0].z:p[1].z; if(p[2].z<zmin) zmin=p[2].z;
  if(zmax<NEAR_Z || zmin>fog_end) return;               /* behind / beyond render distance */
  v3 poly[4]; int n=clip_near(p,3,poly); if(n<3) return;
  int32_t sx[4],sy2[4];
  for(int k=0;k<n;k++) project(poly[k],&sx[k],&sy2[k]);
  uint8_t col=tri_color(p[0].z,p[1].z,p[2].z,hue,bright,fog_start,fog_end);
  for(int k=1;k+1<n;k++){
    int64_t ax=(sx[k]-sx[0])>>16, ay=(sy2[k]-sy2[0])>>16;
    int64_t bx=(sx[k+1]-sx[0])>>16, by=(sy2[k+1]-sy2[0])>>16;
    if(ax*by-bx*ay>=0) continue;                         /* backface (front = negative, y-down) */
    fill_tri(sx[0],sy2[0],sx[k],sy2[k],sx[k+1],sy2[k+1],col);
  }
}

/* Draw one mesh. Painter order = triangle list order (use the BSP for static worlds). */
static void render_mesh(const v3 *verts,int nv,const tri_t *tris,int nt,
                        const cam_t *cam,fx fog_start,fx fog_end){
  v3 vv[MAXV]; camxf x; camxf_init(&x,cam);
  if(nv>MAXV) nv=MAXV;
  for(int i=0;i<nv;i++) vv[i]=to_view(&x,verts[i]);
  for(int i=0;i<nt;i++){
    const tri_t *T=&tris[i];
    draw_tri_view(vv[T->a],vv[T->b],vv[T->c],T->hue,T->bright,fog_start,fog_end);
  }
}

#endif
