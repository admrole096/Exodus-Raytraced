/* core/text.h - FROZEN. Bitmap text into the 8-bit framebuffer. Fonts are DATA (font_t), so a module
 * can ship a bigger font without touching this file. Default font35 = digits + F P S only. */
#ifndef TEXT_H
#define TEXT_H
#include <string.h>
#include "engine.h"

typedef struct {
  const uint8_t *rows;     /* glyph g, row r = rows[g*h + r]; bit (w-1-col) = pixel */
  int w,h,adv;             /* glyph size and horizontal advance */
  int (*glyph)(char);      /* char -> glyph index, or -1 for blank */
} font_t;

static const uint8_t font35_rows[13][5]={
 {7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},
 {7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7},
 {7,4,6,4,4},{7,5,7,4,4},{7,4,7,1,7}};                         /* 0-9 F P S */
static int font35_glyph(char c){
  if(c>='0'&&c<='9') return c-'0';
  return c=='F'?10:c=='P'?11:c=='S'?12:-1;
}
static const font_t FONT35={&font35_rows[0][0],3,5,4,font35_glyph};

static inline void put_px(int x,int y,uint8_t c){ if((unsigned)x<SW&&(unsigned)y<SH) fb[y*SW+x]=c; }
static int text_width(const font_t *f,const char *s){ int n=(int)strlen(s); return n?n*f->adv-(f->adv-f->w):0; }
static void draw_text_f(const font_t *f,int x,int y,const char *s,uint8_t col,uint8_t shadow){
  for(int pass=0;pass<2;pass++){
    int cx=x+(pass==0), cy=y+(pass==0); uint8_t c=pass==0?shadow:col;
    for(const char *p=s;*p;p++,cx+=f->adv){
      int g=f->glyph(*p); if(g<0) continue;
      for(int r=0;r<f->h;r++) for(int b=0;b<f->w;b++)
        if(f->rows[g*f->h+r]&(1<<(f->w-1-b))) put_px(cx+b,cy+r,c);
    }
  }
}
#endif
