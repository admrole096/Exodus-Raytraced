/* core/physics.h - FROZEN. Player physics library: gravity, jump, accel/friction, ground-only collision.
 * Extension points (no edits needed):
 *   - phys_params_t : every tunable is runtime data.
 *   - floor_source  : any module can add a "ground provider" callback (meshes, heightmaps, moving platforms...).
 * Variable delta: the caller clamps dt. Ground = highest provided surface <= feet+step_up (swept ray). */
#ifndef PHYSICS_H
#define PHYSICS_H
#include "engine.h"

typedef struct {
  fx gravity,jump_v,step_up,run_speed,ground_acc,air_acc,fly_speed,eye_h,kill_y;
} phys_params_t;
static inline phys_params_t phys_defaults(void){
  phys_params_t p={FXF(20.0),FXF(7.0),FXF(0.5),FXF(5.0),FXF(40.0),FXF(8.0),FXF(8.0),FXF(1.6),FXF(-60.0)};
  return p;                       /* jump apex = jump_v^2/2g ~ 1.2 units */
}

typedef struct { const v3 *v; const tri_t *t; int nt; } mesh_ref;
typedef struct { v3 pos; fx vx,vy,vz; int ground; } player_t;          /* pos = feet */
typedef int (*floor_fn)(void *ctx,fx px,fx pz,fx ymax,fx *out);         /* 1 = surface found at (px,pz) with y<=ymax */
typedef struct { floor_fn fn; void *ctx; } floor_source;

static inline int64_t edge2(v3 a,v3 b,fx px,fx pz){
  return (int64_t)(b.x-a.x)*(pz-a.z)-(int64_t)(b.z-a.z)*(px-a.x);
}
/* upward-facing triangle containing (px,pz) in the XZ plane, height <= ymax */
static inline int tri_floor_test(v3 a,v3 b,v3 c,fx px,fx pz,fx ymax,fx *out){
  if(edge2(a,b,c.x,c.z)<=0) return 0;
  int64_t w2=edge2(a,b,px,pz); if(w2<0) return 0;
  int64_t w0=edge2(b,c,px,pz); if(w0<0) return 0;
  int64_t w1=edge2(c,a,px,pz); if(w1<0) return 0;
  int64_t den=(w0>>8)+(w1>>8)+(w2>>8); if(den<=0) return 0;
  fx y=(fx)(((w0>>8)*a.y+(w1>>8)*b.y+(w2>>8)*c.y)/den);
  if(y>ymax) return 0;
  *out=y; return 1;
}
/* floor_fn for a mesh_ref (ctx = const mesh_ref*) */
static int mesh_floor(void *ctx,fx px,fx pz,fx ymax,fx *out){
  const mesh_ref *m=ctx; int found=0; fx best=0;
  for(int i=0;i<m->nt;i++){
    const tri_t *T=&m->t[i]; fx y;
    if(tri_floor_test(m->v[T->a],m->v[T->b],m->v[T->c],px,pz,ymax,&y) && (!found||y>best)){ best=y; found=1; }
  }
  *out=best; return found;
}
static int floor_query_sources(const floor_source *s,int n,fx px,fx pz,fx ymax,fx *out){
  int found=0; fx best=0;
  for(int i=0;i<n;i++){ fx y; if(s[i].fn(s[i].ctx,px,pz,ymax,&y) && (!found||y>best)){ best=y; found=1; } }
  *out=best; return found;
}

static inline fx approach(fx v,fx target,fx d){
  if(v<target){ v+=d; if(v>target) v=target; }
  else if(v>target){ v-=d; if(v<target) v=target; }
  return v;
}

/* fwd/strafe in {-1,0,1}; dt = seconds as 16.16 */
static void player_step(player_t *p,const phys_params_t *pp,const floor_source *src,int ns,
                        int fwd,int strafe,int jump,uint16_t yaw,fx dt){
  fx s=fsin(yaw), c=fcos(yaw), spd=pp->run_speed;
  if(fwd&&strafe) spd=fxmul(spd,FXF(0.7071));
  fx wx=fxmul(s*fwd+c*strafe,spd), wz=fxmul(c*fwd-s*strafe,spd);
  fx acc=fxmul(p->ground?pp->ground_acc:pp->air_acc,dt);
  p->vx=approach(p->vx,wx,acc); p->vz=approach(p->vz,wz,acc);
  if(jump&&p->ground){ p->vy=pp->jump_v; p->ground=0; }
  p->vy-=fxmul(pp->gravity,dt);
  fx oldy=p->pos.y, newy=oldy+fxmul(p->vy,dt);
  p->pos.x+=fxmul(p->vx,dt); p->pos.z+=fxmul(p->vz,dt);
  fx h;
  if(p->vy<=0 && floor_query_sources(src,ns,p->pos.x,p->pos.z,oldy+pp->step_up,&h) && newy<=h){
    p->pos.y=h; p->vy=0; p->ground=1;
  } else { p->pos.y=newy; p->ground=0; }
  if(p->pos.y<pp->kill_y){ p->pos.y=FXF(5); p->vy=0; }
}

/* physics off: noclip fly. up in {-1,0,1} */
static void player_fly(player_t *p,const phys_params_t *pp,int fwd,int strafe,int up,uint16_t yaw,fx dt){
  fx s=fsin(yaw), c=fcos(yaw), sp=fxmul(pp->fly_speed,dt);
  p->pos.x+=fxmul(s*fwd+c*strafe,sp); p->pos.z+=fxmul(c*fwd-s*strafe,sp);
  p->pos.y+=fxmul(FX_ONE*up,sp);
  p->vx=p->vy=p->vz=0; p->ground=0;
}
#endif
