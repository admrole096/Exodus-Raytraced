/* Milestone 2 tests: physics, OBJ conversion round-trip, HUD render. Headless. */
#include <stdio.h>
#include <math.h>
#include "engine.h"
#include "shapes.h"
#include "physics.h"
#include "text.h"
#include "obj.h"

static int fails=0;
static void check(const char *n,double got,double want,double tol){
  int ok=fabs(got-want)<=tol; if(!ok) fails++;
  printf("%s %-34s got %8.3f want %8.3f\n",ok?"PASS":"FAIL",n,got,want);
}
static double F(fx v){ return v/65536.0; }

static void write_test_obj(const char *p){
  FILE *f=fopen(p,"w");
  fputs("# cube (quads, slashes) then pyramid (negative indices)\n"
   "v -1 -1 -1\nv 1 -1 -1\nv 1 1 -1\nv -1 1 -1\nv -1 -1 1\nv 1 -1 1\nv 1 1 1\nv -1 1 1\n"
   "vt 0 0\nvn 0 0 1\n"
   "f 5/1/1 6/1/1 7/1/1 8/1/1\nf 2 1 4 3\nf 6 2 3 7\nf 1 5 8 4\nf 8 7 3 4\nf 1 2 6 5\n"
   "v -1 0 -1\nv 1 0 -1\nv 1 0 1\nv -1 0 1\nv 0 2 0\n"
   "f -5 -4 -3 -2\nf -2 -3 -1\nf -4 -5 -1\nf -3 -4 -1\nf -5 -2 -1\n",f);
  fclose(f);
}

static phys_params_t PP;
static void sim(player_t *p,const floor_source *w,int nm,double secs,double dt,int fwd,int jump0,double *apex){
  int n=(int)(secs/dt);
  for(int i=0;i<n;i++){
    player_step(p,&PP,w,nm,fwd,0,i==0&&jump0,0,FXF(dt));
    if(apex&&F(p->pos.y)>*apex) *apex=F(p->pos.y);
  }
}

int main(void){
  engine_init();
  v3 gv[8],cv[8]; tri_t gt[12],ct[12];
  box_mesh(0,FXF(-1.5),0,FXF(30),FXF(0.5),FXF(30),4,gv,gt);   /* ground top y=-1 */
  box_mesh(0,0,FXF(2),FXF(1),FXF(1),FXF(1),1,cv,ct);          /* cube top y=1, z 1..3 */

  /* --- OBJ: convert, save, reload --- */
  write_test_obj("t.obj");
  mesh_t cube={0},rl={0};
  int r=obj_load("t.obj",1.0,1,&cube); printf("obj_load rc=%d verts=%d tris=%d\n",r,cube.nv,cube.nt);
  check("obj verts (8 cube + 5 pyramid)",cube.nv,13,0);
  check("obj tris (12 cube + 6 pyramid)",cube.nt,18,0);
  /* split: first 12 tris/8 verts cube, rest pyramid (indices already global) */
  mesh_save(&cube,"t.m3d"); r=mesh_load(&rl,"t.m3d");
  check("m3d roundtrip rc",r,0,0);
  check("m3d roundtrip verts equal",memcmp(rl.v,cube.v,cube.nv*sizeof(v3))==0,1,0);
  check("m3d roundtrip tris equal",memcmp(rl.t,cube.t,cube.nt*sizeof(tri_t))==0,1,0);
  mesh_free(&rl);
  mesh_translate(&cube,-3,0,4);                               /* whole file: cube + pyramid */
  /* pyramid lives in same mesh; shift it separately by re-translating its verts (8..12) */
  for(int i=8;i<13;i++){ cube.v[i].x+=FXF(6); cube.v[i].y+=FXF(-1); }  /* pyramid -> (3,-1..1,4) */
  for(int i=0;i<8;i++) cube.v[i].y+=FXF(-0); /* cube stays y -1..1 at (-3,*,4) */

  mesh_ref mr[3]={{gv,gt,12},{cv,ct,12},{cube.v,cube.t,cube.nt}};
  floor_source world[3]={{mesh_floor,&mr[0]},{mesh_floor,&mr[1]},{mesh_floor,&mr[2]}};
  PP=phys_defaults();

  /* --- physics --- */
  player_t p; double apex;
  memset(&p,0,sizeof p); p.pos=(v3){0,FXF(5),FXF(-8)};
  sim(&p,world,3,2.0,0.016,0,0,0);
  check("fall to ground (y)",F(p.pos.y),-1.0,0.01); check("grounded",p.ground,1,0);

  apex=-99; sim(&p,world,3,1.5,0.016,0,1,&apex);
  check("jump apex height",apex-(-1.0),1.225,0.08);
  check("landed again",F(p.pos.y),-1.0,0.01);

  memset(&p,0,sizeof p); p.pos=(v3){0,FXF(5),FXF(2)};
  sim(&p,world,3,2.0,0.016,0,0,0);
  check("land on cube top (y)",F(p.pos.y),1.0,0.01);
  sim(&p,world,3,2.0,0.016,1,0,0);                             /* walk +z off the cube */
  check("walked off, back on ground",F(p.pos.y),-1.0,0.01);
  check("walked past cube edge (z>3)",F(p.pos.z)>3.0,1,0);

  memset(&p,0,sizeof p); p.pos=(v3){FXF(3),FXF(5),FXF(4)};
  sim(&p,world,3,2.0,0.016,0,0,0);
  check("land on pyramid apex (y)",F(p.pos.y),1.0,0.02);
  memset(&p,0,sizeof p); p.pos=(v3){FXF(3.5),FXF(5),FXF(4.2)};
  sim(&p,world,3,2.0,0.016,0,0,0);
  check("land on pyramid slope (y)",F(p.pos.y),0.0,0.02);

  memset(&p,0,sizeof p); p.pos=(v3){0,FXF(8),FXF(-8)};
  sim(&p,world,3,2.0,0.050,0,0,0);                             /* worst-case clamped dt */
  check("no tunnelling at dt=50ms",F(p.pos.y),-1.0,0.01);

  memset(&p,0,sizeof p); p.pos=(v3){0,FXF(-1),FXF(-8)}; p.ground=1;
  sim(&p,world,3,1.0,0.016,1,0,0);
  check("run speed reached (z moved ~4.5)",F(p.pos.z)-(-8.0),4.5,0.8);

  /* --- render with HUD --- */
  p.pos=(v3){FXF(0),FXF(-1),FXF(-4)};
  cam_t c={{p.pos.x,p.pos.y+PP.eye_h,p.pos.z},DEG(15),DEG(-10)};
  clear_fb(15);
  render_mesh(gv,8,gt,12,&c,FXF(10),FXF(40));
  render_mesh(cv,8,ct,12,&c,FXF(10),FXF(40));
  render_mesh(cube.v,cube.nv,cube.t,cube.nt,&c,FXF(10),FXF(40));
  draw_text_f(&FONT35,(SW-text_width(&FONT35,"FPS 60"))/2,2,"FPS 60",11*16,12*16+9);
  FILE *o=fopen("m2.ppm","wb"); fprintf(o,"P6\n%d %d\n255\n",SW,SH);
  for(int i=0;i<SW*SH;i++){ uint32_t q=pal[fb[i]]; fputc(q>>16,o); fputc(q>>8,o); fputc(q,o); } fclose(o);

  printf("\n%s (%d failures)\n",fails?"SOME TESTS FAILED":"ALL PASSED",fails);
  mesh_free(&cube); return fails!=0;
}
