/* Headless test: renders frames to PPM and benchmarks. No SDL needed. */
#include <stdio.h>
#include <time.h>
#include "engine.h"
#include "shapes.h"

static void dump(const char *name){
  FILE *f=fopen(name,"wb"); fprintf(f,"P6\n%d %d\n255\n",SW,SH);
  for(int i=0;i<SW*SH;i++){ uint32_t c=pal[fb[i]]; fputc(c>>16,f); fputc(c>>8,f); fputc(c,f); }
  fclose(f);
}

int main(void){
  engine_init();
  v3 cv[8], fv[8]; tri_t ct[12], ft[12];
  box_mesh(0,FXF(0),FXF(2),FXF(1),FXF(1),FXF(1),1,cv,ct);            /* cube, red   */
  box_mesh(FXF(3),FXF(-0.5),FXF(5),FXF(0.5),FXF(0.5),FXF(0.5),7,fv,ft); /* small blue box */
  v3 gv[8]; tri_t gt[12];
  box_mesh(0,FXF(-1.5),FXF(0),FXF(30),FXF(0.5),FXF(30),4,gv,gt);       /* ground slab */

  struct { double px,py,pz,yaw,pitch; const char *n; } F[4]={
    {0,0.5,-5, 0, 0,  "f0.ppm"},
    {0,2.0,-5, 0,-20, "f1.ppm"},   /* look down */
    {0,0.0,-5, 0, 25, "f2.ppm"},   /* look up   */
    {-6,2.0,-2, 60,-15,"f3.ppm"}};
  for(int i=0;i<4;i++){
    cam_t c={{FXF(F[i].px),FXF(F[i].py),FXF(F[i].pz)},DEG(F[i].yaw),DEG(F[i].pitch)};
    clear_fb(15);
    render_mesh(gv,8,gt,12,&c,FXF(8),FXF(30));
    render_mesh(cv,8,ct,12,&c,FXF(8),FXF(30));
    render_mesh(fv,8,ft,12,&c,FXF(8),FXF(30));
    dump(F[i].n);
  }
  cam_t c={{0,FXF(1),FXF(-5)},0,0}; volatile uint32_t sink=0;
  clock_t t0=clock(); int N=20000;
  for(int i=0;i<N;i++){
    c.yaw=(uint16_t)(i*37);
    clear_fb(15);
    render_mesh(gv,8,gt,12,&c,FXF(8),FXF(30));
    render_mesh(cv,8,ct,12,&c,FXF(8),FXF(30));
    render_mesh(fv,8,ft,12,&c,FXF(8),FXF(30));
    sink+=fb[(i*131)%(SW*SH)]+fb[SW*SH/2+i%SW];
  }
  uint32_t sum=sink; for(int i=0;i<SW*SH;i++) sum+=fb[i];
  double ms=(clock()-t0)*1000.0/CLOCKS_PER_SEC/N;
  printf("%.4f ms/frame (%d x %d, 36 tris) chk=%u\n",ms,SW,SH,sum);
  return 0;
}
