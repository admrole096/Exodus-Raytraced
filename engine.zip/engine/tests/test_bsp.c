/* BSP test: compares painter-order rendering vs BSP against a per-pixel z-buffer reference. */
#include <stdio.h>
#include <time.h>
#include "engine.h"
#include "shapes.h"
#include "bsp.h"

static uint8_t ref[SW*SH]; static double zb[SW*SH];

static void ref_render(const wtri_t *T,int n,const cam_t *cam,fx fs,fx fe){
  camxf x; camxf_init(&x,cam);
  memset(ref,15,sizeof ref); for(int i=0;i<SW*SH;i++) zb[i]=1e30;
  for(int t=0;t<n;t++){
    v3 v[3]; for(int k=0;k<3;k++) v[k]=to_view(&x,T[t].v[k]);
    if(v[0].z<NEAR_Z||v[1].z<NEAR_Z||v[2].z<NEAR_Z) continue;
    fx zmin=v[0].z<v[1].z?v[0].z:v[1].z; if(v[2].z<zmin) zmin=v[2].z; if(zmin>fe) continue;
    double sx[3],sy[3],z[3];
    for(int k=0;k<3;k++){ z[k]=v[k].z/65536.0; sx[k]=SW/2.0+(v[k].x/65536.0)*FOCAL/z[k]; sy[k]=SH/2.0-(v[k].y/65536.0)*FOCAL/z[k]; }
    double area=(sx[1]-sx[0])*(sy[2]-sy[0])-(sx[2]-sx[0])*(sy[1]-sy[0]);
    if(area>=0) continue;                                  /* backface, same rule as engine */
    uint8_t col=tri_color(v[0].z,v[1].z,v[2].z,T[t].hue,T[t].bright,fs,fe);
    for(int py=0;py<SH;py++) for(int px=0;px<SW;px++){
      double w0=((sx[1]-px)*(sy[2]-py)-(sx[2]-px)*(sy[1]-py))/area;
      double w1=((sx[2]-px)*(sy[0]-py)-(sx[0]-px)*(sy[2]-py))/area;
      double w2=1.0-w0-w1;
      if(w0<-1e-9||w1<-1e-9||w2<-1e-9) continue;
      double d=1.0/(w0/z[0]+w1/z[1]+w2/z[2]);
      if(d<zb[py*SW+px]){ zb[py*SW+px]=d; ref[py*SW+px]=col; }
    }
  }
}
static int diff(const uint8_t *a,const uint8_t *b){ int n=0; for(int i=0;i<SW*SH;i++) n+=a[i]!=b[i]; return n; }
static void dump(const char *nm,const uint8_t *p){
  FILE *f=fopen(nm,"wb"); fprintf(f,"P6\n%d %d\n255\n",SW,SH);
  for(int i=0;i<SW*SH;i++){ uint32_t c=pal[p[i]]; fputc(c>>16,f); fputc(c>>8,f); fputc(c,f); } fclose(f);
}

int main(void){
  engine_init();
  v3 v[4][8]; tri_t t[4][12]; tri_list L={0,0,0};
  box_mesh(0,FXF(-1.5),0,FXF(7),FXF(0.5),FXF(7),4,v[0],t[0]);                  /* ground      */
  box_mesh(0,0,0,FXF(1),FXF(1),FXF(1),1,v[1],t[1]);                            /* cube A      */
  box_mesh(FXF(1.0),FXF(0.5),FXF(0.8),FXF(1),FXF(1),FXF(1),7,v[2],t[2]);       /* cube B, interpenetrates A */
  box_mesh(FXF(-2.5),FXF(1),FXF(1.5),FXF(0.4),FXF(2),FXF(0.4),3,v[3],t[3]);    /* tall pillar */
  for(int i=0;i<4;i++) tl_add_mesh(&L,v[i],8,t[i],12);

  bsp_t B; clock_t c0=clock(); bsp_build(&L,&B);
  printf("input %d tris -> BSP %d tris, %d nodes, %d splits (build %.2f ms)\n",
         L.n,B.nt,B.nn,B.splits,(clock()-c0)*1000.0/CLOCKS_PER_SEC);

  struct { double x,y,z,yaw,pitch; } C[5]={
    {0,6,-9,0,-25},{8,5,-6,-53,-26},{-7,4,5,125.5,-25},{0,9,-3,0,-70},{4,3,-11,-20,-14.4}};
  int worst_bsp=0; double sum_p=0,sum_b=0;
  for(int i=0;i<5;i++){
    cam_t cam={{FXF(C[i].x),FXF(C[i].y),FXF(C[i].z)},DEG(C[i].yaw),DEG(C[i].pitch)};
    ref_render(B.t,B.nt,&cam,FXF(20),FXF(60));
    static uint8_t pa[SW*SH],bs[SW*SH];
    clear_fb(15); camxf x; camxf_init(&x,&cam);                       /* naive painter: input order */
    for(int k=0;k<L.n;k++) draw_tri_view(to_view(&x,L.t[k].v[0]),to_view(&x,L.t[k].v[1]),to_view(&x,L.t[k].v[2]),L.t[k].hue,L.t[k].bright,FXF(20),FXF(60));
    memcpy(pa,fb,sizeof pa);
    clear_fb(15); bsp_render(&B,&cam,FXF(20),FXF(60)); memcpy(bs,fb,sizeof bs);
    int dp=diff(pa,ref), db=diff(bs,ref);
    printf("cam %d: painter-order mismatch %5.2f%%   BSP mismatch %5.2f%%\n",i,dp*100.0/(SW*SH),db*100.0/(SW*SH));
    sum_p+=dp; sum_b+=db; if(db>worst_bsp) worst_bsp=db;
    if(i==1||i==2){ char n[32]; sprintf(n,"p%d.ppm",i); dump(n,pa); sprintf(n,"b%d.ppm",i); dump(n,bs); sprintf(n,"r%d.ppm",i); dump(n,ref); }
  }
  cam_t cam={{FXF(8),FXF(5),FXF(-6)},DEG(-53),DEG(-26)};
  int N=5000; volatile uint32_t sink=0; clock_t t0=clock();
  for(int i=0;i<N;i++){ cam.yaw=DEG(-53)+(uint16_t)(i&63); clear_fb(15); bsp_render(&B,&cam,FXF(20),FXF(60)); sink+=fb[(i*131)%(SW*SH)]; }
  printf("BSP render: %.4f ms/frame (%d tris)\n",(clock()-t0)*1000.0/CLOCKS_PER_SEC/N,B.nt);
  int ok = worst_bsp*100.0/(SW*SH) < 3.0 && sum_b < sum_p;
  printf("%s\n",ok?"PASS: BSP order matches z-buffer reference and beats painter order":"FAIL");
  bsp_free(&B); free(L.t); return !ok;
}
