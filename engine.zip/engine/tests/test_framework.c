/* Framework tests: module system, services, commands, headless frames, and - the point of the design -
 * EXTENSION WITHOUT MODIFICATION: a module defined in this file adds ground, an action and a command
 * using only the public API. */
#include <stdio.h>
#include <math.h>
#include "game.h"
#include "controls.h"
#include "world.h"
#include "demo_scene.h"
#include "player.h"
#include "hud.h"
#include "checkpoint.h"
#include "shapes.h"

static int fails=0;
static void check(const char *n,double got,double want,double tol){
  int ok=fabs(got-want)<=tol; if(!ok) fails++;
  printf("%s %-46s got %9.3f want %9.3f\n",ok?"PASS":"FAIL",n,got,want);
}
static double F(fx v){ return v/65536.0; }
static void frames(game_t *g,int n){ for(int i=0;i<n;i++){ input_begin_frame(&g->in); game_frame(g,16); } }

/* ---------- an EXTENSION written only against the public API ---------- */
static int plat_floor(void *ctx,fx px,fx pz,fx ymax,fx *out){
  (void)ctx;                                           /* flat platform y=3 over x 10..12, z -1..1 */
  if(px>=FXF(10)&&px<=FXF(12)&&pz>=FXF(-1)&&pz<=FXF(1)&&FXF(3)<=ymax){ *out=FXF(3); return 1; }
  return 0;
}
static int hello_cmd(game_t *g,int argc,char **argv,char *out,int outn){ (void)g;(void)argc;(void)argv; OUT("hello from an extension"); return 0; }
static int ACT_SPECIAL=-1;
static void ext_init(game_t *g){
  player_state_t *p=game_service(g,"player");
  player_add_floor_source(p,plat_floor,0);
  game_cmd_register(g,"hello",hello_cmd,"extension command");
  ACT_SPECIAL=game_action_id(g,"special",1);           /* new action id in the user range */
}
static const module_t ext_module={GAME_API_VERSION,"ext_platform",ext_init,0,0,0,0};

static game_t G;
int main(void){
  engine_init(); game_init(&G); char out[512];

  /* --- registration --- */
  check("register controls",game_register(&G,&controls_module),0,0);
  check("register world",game_register(&G,&world_module),0,0);
  check("register demo_scene",game_register(&G,&demo_scene_module),0,0);
  check("register player",game_register(&G,&player_module),0,0);
  check("register hud",game_register(&G,&hud_module),0,0);
  module_t bad={0,"bad_api",0,0,0,0,0};
  check("module with wrong api version rejected",game_register(&G,&bad),-1,0);
  check("module count",G.nmods,5,0);
  check("services published (world,player,controls,hud)",
        (game_service(&G,"world")!=0)+(game_service(&G,"player")!=0)+(game_service(&G,"controls")!=0)+(game_service(&G,"hud")!=0),4,0);
  check("unknown service is NULL",game_service(&G,"nope")==0,1,0);

  /* --- commands --- */
  check("cmd: unknown command rc",game_exec(&G,"frobnicate 1",out,sizeof out),-1,0);
  check("cmd: unknown command text",strstr(out,"unknown command")!=0,1,0);
  game_exec(&G,"help",out,sizeof out);
  check("cmd: help lists physics+bind+fog",(strstr(out,"physics")!=0)+(strstr(out,"bind")!=0)+(strstr(out,"fog")!=0),3,0);
  game_exec(&G,"fog 5 25",out,sizeof out);
  check("cmd: fog sets distances",F(G.fog_end),25,0.01);
  game_exec(&G,"fog 10 40",out,sizeof out);
  check("cmd: bad key rc",game_exec(&G,"bind zzz jump",out,sizeof out),-1,0);
  check("cmd: bad action rc",game_exec(&G,"bind j fly",out,sizeof out),-1,0);

  /* --- headless frames: player falls from spawn onto the demo ground --- */
  frames(&G,90);
  player_state_t *P=game_service(&G,"player");
  check("player settles on ground (y)",F(P->pl.pos.y),-1.0,0.01);
  check("camera follows (eye height)",F(G.cam.pos.y)-F(P->pl.pos.y),1.6,0.01);
  check("world BSP was built by update hook",((world_t*)game_service(&G,"world"))->bsp.nt>0,1,0);

  /* --- controls: space jumps, rebinding works --- */
  input_begin_frame(&G.in); input_key(&G.in,K_SPACE,1); game_frame(&G,16);
  check("space -> jump (leaves ground)",P->pl.ground,0,0);
  input_key(&G.in,K_SPACE,0); frames(&G,90);
  check("lands again",F(P->pl.pos.y),-1.0,0.01);
  game_exec(&G,"bind j jump",out,sizeof out);
  input_begin_frame(&G.in); input_key(&G.in,'j',1); game_frame(&G,16);
  check("rebind: j now jumps",P->pl.ground,0,0);
  input_key(&G.in,'j',0); frames(&G,90);
  game_exec(&G,"unbind j",out,sizeof out);
  input_key(&G.in,'j',1); frames(&G,2);
  check("unbind: j no longer jumps",P->pl.ground,1,0);
  input_key(&G.in,'j',0);

  /* --- physics toggle by key and by command --- */
  input_begin_frame(&G.in); input_key(&G.in,'p',1); game_frame(&G,16); input_key(&G.in,'p',0);
  check("key p: physics off",P->physics_on,0,0);
  double y0=F(P->pl.pos.y);
  input_key(&G.in,K_SPACE,1); frames(&G,30); input_key(&G.in,K_SPACE,0);
  check("fly mode: space rises ~3.8 units in 0.48s",F(P->pl.pos.y)-y0,3.84,0.3);
  game_exec(&G,"physics on",out,sizeof out);
  check("cmd physics on",P->physics_on,1,0);
  frames(&G,200);
  check("falls back to ground",F(P->pl.pos.y),-1.0,0.01);
  game_exec(&G,"gravity 10",out,sizeof out);
  check("cmd gravity",F(P->pp.gravity),10.0,0.01);
  game_exec(&G,"gravity 20",out,sizeof out);

  /* --- EXTENSION without modification --- */
  check("register extension module",game_register(&G,&ext_module),0,0);
  check("extension command works",game_exec(&G,"hello",out,sizeof out),0,0);
  check("extension command text",strstr(out,"extension")!=0,1,0);
  check("extension got a user action id",ACT_SPECIAL>=ACT_USER0,1,0);
  game_exec(&G,"bind k special",out,sizeof out);
  input_begin_frame(&G.in); input_key(&G.in,'k',1); game_frame(&G,16);
  check("user action fires from bound key",G.act_down[ACT_SPECIAL],1,0);
  input_key(&G.in,'k',0);
  game_exec(&G,"tp 11 8 0",out,sizeof out); frames(&G,120);
  check("lands on extension's platform (y=3)",F(P->pl.pos.y),3.0,0.01);

  /* --- runtime world modification --- */
  world_t *W=game_service(&G,"world"); v3 v[8]; tri_t t[12];
  box_mesh(FXF(-6),0,0,FXF(1),FXF(1),FXF(1),2,v,t);
  int before=W->bsp.nt; world_add_mesh(W,v,8,t,12); frames(&G,1);
  check("BSP rebuilt after runtime add (more tris)",W->bsp.nt>before,1,0);
  game_exec(&G,"tp -6 8 0",out,sizeof out); frames(&G,120);
  check("lands on runtime-added box (y=1)",F(P->pl.pos.y),1.0,0.01);

  /* --- worked example module from modules/checkpoint.h --- */
  check("register checkpoint example",game_register(&G,&checkpoint_module),0,0);
  game_exec(&G,"tp 5 4 -3",out,sizeof out); frames(&G,120);
  game_exec(&G,"checkpoint",out,sizeof out);
  check("checkpoint command text",strstr(out,"saved")!=0,1,0);
  game_exec(&G,"tp 20 4 20",out,sizeof out); frames(&G,5);
  input_begin_frame(&G.in); input_key(&G.in,'r',1); game_frame(&G,16); input_key(&G.in,'r',0);
  check("R respawns at checkpoint (x)",F(P->pl.pos.x),5.0,0.3);
  check("R respawns at checkpoint (z)",F(P->pl.pos.z),-3.0,0.3);

  /* --- quit via action --- */
  input_begin_frame(&G.in); input_key(&G.in,K_ESC,1); game_frame(&G,16);
  check("esc quits (running=0)",G.running,0,0);

  game_shutdown(&G);
  printf("\n%s (%d failures)\n",fails?"SOME TESTS FAILED":"ALL PASSED",fails);
  return fails!=0;
}
