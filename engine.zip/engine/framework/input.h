/* framework/input.h - FROZEN. Platform-neutral input state. Platforms (SDL, tests) FILL it; modules READ it.
 * Key codes: lowercase ASCII for printable keys, K_* for the rest. */
#ifndef INPUT_H
#define INPUT_H
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

enum { K_NONE=0, K_BACKSPACE=8, K_TAB=9, K_ENTER=13, K_ESC=27, K_SPACE=' ',
       K_LCTRL=128, K_RCTRL, K_LSHIFT, K_RSHIFT, K_LALT, K_RALT, K_UP, K_DOWN, K_LEFT, K_RIGHT,
       K_F1=140 /* .. K_F12=151 */ };

typedef struct {
  uint8_t down[256];       /* held this frame */
  uint8_t pressed[256];    /* went down this frame (edge) */
  uint8_t released[256];   /* went up this frame (edge) */
  int mouse_dx,mouse_dy;   /* relative motion this frame */
} input_t;

static inline void input_begin_frame(input_t *in){
  memset(in->pressed,0,256); memset(in->released,0,256); in->mouse_dx=in->mouse_dy=0;
}
static inline void input_key(input_t *in,int key,int is_down){
  key&=255;
  if(is_down&&!in->down[key]) in->pressed[key]=1;
  if(!is_down&&in->down[key]) in->released[key]=1;
  in->down[key]=is_down?1:0;
}
static inline void input_mouse(input_t *in,int dx,int dy){ in->mouse_dx+=dx; in->mouse_dy+=dy; }

static const struct { const char *name; int key; } KEY_NAMES[]={
  {"space",K_SPACE},{"esc",K_ESC},{"enter",K_ENTER},{"tab",K_TAB},{"backspace",K_BACKSPACE},
  {"lctrl",K_LCTRL},{"rctrl",K_RCTRL},{"lshift",K_LSHIFT},{"rshift",K_RSHIFT},{"lalt",K_LALT},{"ralt",K_RALT},
  {"up",K_UP},{"down",K_DOWN},{"left",K_LEFT},{"right",K_RIGHT},{0,0}};

/* "w" -> 'w', "space" -> K_SPACE, "f5" -> K_F1+4. Returns 0 if unknown. */
static int key_from_name(const char *n){
  if(!n||!*n) return 0;
  if(!n[1]) return tolower((unsigned char)n[0]);
  for(int i=0;KEY_NAMES[i].name;i++) if(!strcmp(KEY_NAMES[i].name,n)) return KEY_NAMES[i].key;
  if((n[0]=='f'||n[0]=='F')&&atoi(n+1)>=1&&atoi(n+1)<=12) return K_F1+atoi(n+1)-1;
  return 0;
}
#endif
